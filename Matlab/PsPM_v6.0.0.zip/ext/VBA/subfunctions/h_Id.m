function h = h_Id(yt,t,in)
h = in.u(t);